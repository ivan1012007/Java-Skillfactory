package org.example;

public interface StudentComp extends Comparator<Student>, java.util.Comparator<Student> {

}
