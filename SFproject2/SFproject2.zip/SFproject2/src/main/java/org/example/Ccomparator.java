package org.example;

import java.util.Comparator;

public interface Ccomparator<University> {
    public int compareTo(University b, University b1);
}
