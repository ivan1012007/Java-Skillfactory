package org.example;

public enum StudentEnum {
    Fullname,
    Universityid,
    Avgexamscore,
    Currentcoursenumber
}
