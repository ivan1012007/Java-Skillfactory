package org.example;

public enum UniversityEnum {
    Id,
    FullName,
    ShortName,
    YearOfFoundation,
    MainProfile
}
