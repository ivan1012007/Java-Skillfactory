package org.example;

public interface Comparator <Student>  {
    public int compareTo(Student o1, Student o2);
    public int compare (org.example.Student o1, org.example.Student o2);
    public int compar(Student o1, Student o2);
    public int compare1 (Student o1, Student o2);
}
