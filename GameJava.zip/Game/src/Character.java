public abstract class Character implements Combat {
    private String name;
    private int health;
    private int gold;
    private int agility;
    private int experience;
    private int strength;

    public Character(String name, int health, int agility, int gold, int experience, int strength) {
        this.name = name;
        this.health = health;
        this.gold = gold;
        this.experience = experience;
        this.strength = strength;
        this.agility = agility;
    }

    @Override
    public int Attack() {
        if (agility * 100 >= hitChance()) {
            if (RandomNumber() > 70) {
                return (strength * 2);
            } else {
                return strength;
            }
        } else {
            return 0;
        }
    }

    public double RandomNumber() {
        return Math.random() * 100;
    }

    public int hitChance() {
        return (int) (Math.random() * 10);
    }

    public String getName() {
        return name;
    }

    public int getHealth() {
        return health;
    }

    public int getGold() {
        return gold;
    }

    public int getExperience() {
        return experience;
    }

    public int getStrength() {
        return strength;
    }

    public int getAgility() {
        return agility;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAgility(int agility) {
        this.agility = agility;
    }

    @Override
    public String toString() {
        return String.format("%s HP:%d", name, health);
    }
}
