import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Game1{
    private static BufferedReader br;
    private static Character player = null;
    private static Battle battle = null;

    public static void main(String[] args){
        br = new BufferedReader(new InputStreamReader(System.in));
        battle = new Battle();
        System.out.println("Enter your character name:");
        try{
            command(br.readLine());
        } catch (
            IOException e) {
            e.printStackTrace();
        }
        }

    private static void command(String string) throws IOException {
        if (player == null) {
            player = new Klass(
                    string,
                    100,
                    20,
                    20,
                    0,
                    0
            );
            System.out.println(String.format("You are the chosen one, %s! Defeat all the enemies and become the Gladiator!", player.getName()));
            printNavigation();
        }
        switch (string) {
            case "1": {
                System.out.println("The vendor has been killed! Avenge him!");
                command(br.readLine());
            }
            break;
            case "2": {
                commitFight();
            }
            break;
            case "3":
                System.exit(1);
                break;
            case "y":
                command("2");
                break;
            case "n": {
                printNavigation();
                command(br.readLine());
            }
        }
        command(br.readLine());
    }
    private static void printNavigation() {
        System.out.println("Choose your destiny");
        System.out.println("1. Go to vendor");
        System.out.println("2. Enter Arena");
        System.out.println("3. Exit");
    }
    private static void commitFight() {
        battle.fight(player, createMonster(), new FightCallback() {
            @Override
            public void Victory() {
                System.out.println(String.format("%s is victorious! You now have %d exp. and %d gold, as well as %d HP.", player.getName(), player.getExperience(), player.getGold(), player.getHealth()));
                System.out.println("Continue your journey? (y/n)");
                try {
                    command(br.readLine());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void Defeat() {

            }
        });
    }
    private static Character createMonster() {

        int random = (int) (Math.random() * 10);

        if (random % 2 == 0) return new Goblin(
                "Goblin",
                50,
                1000,
                1000,
                100,
                20
        );
        else return new Skeleton(
                "Skeleton",
                25,
                2000,
                2000,
                100,
                10
        );
    }
    interface FightCallback {
        void Victory();
        void Defeat();
    }

}

