public class Klass extends Character{
    public Klass(String name, int health, int agility, int strength, int gold, int experience){
        super (name, health, agility, strength, gold, experience);
    }
}
