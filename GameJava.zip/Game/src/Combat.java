interface Combat {
    public int Attack();
}
