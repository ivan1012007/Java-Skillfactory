public class Battle{
    public void fight(Character hero, Character enemy, Game1.FightCallback fightCallback) {
        Runnable runnable = () -> {
            int turn = 1;
            boolean FightOver = false;
            while (!FightOver) {
                System.out.println("Now is the " + turn + " turn");
                if (turn++ % 2 != 0) {
                    FightOver = Strike(enemy, hero, fightCallback);} else {
                        FightOver = Strike(hero, enemy, fightCallback);
                    }
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            };
        Thread thread = new Thread(runnable);
        thread.start();
    }

    private Boolean Strike(Character defender, Character attacker, Game1.FightCallback fightCallback) {
        int strk = attacker.Attack();
        int defHP = defender.getHealth() - strk;
        if (strk != 0) {
            System.out.println(String.format("%s struck for %d health ", attacker.getName(), strk));
            System.out.println(String.format("%s has %d HP left", defender.getName(), defHP));
        } else {
            System.out.println(String.format("%s missed!", attacker.getName()));
        }
        if (defHP <= 0 && defender instanceof Klass) {
            System.out.println("The hero has fallen in battle");
            fightCallback.Defeat();
            return true;
        } else if (defHP <= 0) {
            System.out.println(String.format("You slayed the enemy! You gain %d exp. and %d gold!", defender.getExperience(), defender.getGold()));
            attacker.setExperience(attacker.getExperience() + defender.getExperience());
            attacker.setGold(attacker.getGold() + defender.getGold());
            fightCallback.Victory();
            return true;
        } else {
            defender.setHealth(defHP);
            return false;
        }
    }
}
