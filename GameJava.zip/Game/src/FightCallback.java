interface FightCallback {
    void Victory();
    void Defeat();
}
