public class Skeleton extends Character{
    public Skeleton(String name, int health, int strength, int agility, int gold, int experience){
        super (name, health, strength, agility, gold, experience);
    }
}
