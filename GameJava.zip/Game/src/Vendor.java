public interface Vendor {
    String Sell(Seller.Goods goods);
}
