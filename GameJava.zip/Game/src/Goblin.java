public class Goblin extends Character{
    public Goblin (String name, int health, int strength, int agility, int gold, int experience){
        super (name, health, strength, agility, gold, experience);
    }
}
